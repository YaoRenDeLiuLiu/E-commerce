<?php 

$con = mysqli_connect("localhost","root","","ecom_store");

?>

<center><!--  center Begin  -->
    
    <h1> Shipping Track </h1>
    
    <p class="text-muted">
        
        The paid goods will be dilived soon.
        
    </p>
    
</center><!--  center Finish  -->

<div id="content"><!-- #content Begin -->
<div class="table-responsive"><!--  table-responsive Begin  -->
    <table class="table table-bordered table-hover"><!--  table table-bordered table-hover Begin  -->
            <thead><!-- thead Begin -->
                            
                <tr><!-- tr Begin -->
                    <th>Products</th>          
                    <th>ORDER DATE</th>
                    <th>ORDER NUMBER</th>
                    <th>INVOICE NUMBER</th>
                    <th>ORDER TOTAL</th>
                    <th>DAY ACHIEVE</th>                                       
                </tr><!-- tr Finish -->
                            
            </thead><!-- thead Finish -->
             <?php

            global $con;

            $customer_session = $_SESSION['customer_email'];

            $get_customer = "select * from customers where customer_email='$customer_session'";

            $run_customer = mysqli_query($con,$get_customer);

            $row_customer = mysqli_fetch_array($run_customer);

            $customer_id = $row_customer['customer_id'];

            $get_orders = "select * from customer_orders where customer_id='$customer_id' ";

                $run_track = mysqli_query($con, $get_orders);
                while($row_orders = mysqli_fetch_array($run_track)){


                    $order_id = $row_orders['order_id'];
                  
                    $due_amount = $row_orders['due_amount'];

                    $invoice_no = $row_orders['invoice_no'];
                   
                    $order_date = substr($row_orders['order_date'],0,11);
                    
                    $order_status = $row_orders['order_status'];


                    $get_pending_orders = "select * from pending_orders where invoice_no='$invoice_no' ";

                    $run_pending = mysqli_query($con, $get_pending_orders);

                    while($row_pending = mysqli_fetch_array($run_pending)){

                        $product_id = $row_pending['product_id'];

                        $get_product_img = "select * from products where product_id='$product_id' ";
                        $run_product_img = mysqli_query($con, $get_product_img);
                        while($row_product_img = mysqli_fetch_array($run_product_img)){
                            $product_img = $row_product_img['product_img1'];
            ?>     
            <?php if($order_status=='Complete'){
                        echo "<thead><!-- thead Begin -->
                            
                        <tr><!-- tr Begin -->
                            <td><img  src='../admin_area/product_images/$product_img'height='100' width='100'></td>        
                            <td>$order_date</td>
                            <td>$order_id</td>
                            <td>$invoice_no</td>
                            <td>$ $due_amount</td>
                            <td>7 Days</td> 
                                                                               
                        </tr><!-- tr Finish -->
                                    
                    </thead><!-- thead Finish -->  ";
                    }
  
            ?>
            <?php }}} ?>
    </table><!--  table table-bordered table-hover Finish  -->     
</div><!--  table-responsive Finish  -->
</div><!-- #content Finish -->