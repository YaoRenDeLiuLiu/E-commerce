<?php 

$con = mysqli_connect("localhost","root","","ecom_store");

?>

<center><!--  center Begin  -->
    
    <h1> My favorite </h1>
    
    <p class="text-muted">
        
        These goods had in your order (paid or not paid).
        
    </p>
    
</center><!--  center Finish  -->

<div id="content"><!-- #content Begin -->
<div class="table-responsive"><!--  table-responsive Begin  -->
    <table class="table table-bordered table-hover"><!--  table table-bordered table-hover Begin  -->
            <thead><!-- thead Begin -->
                            
                <tr><!-- tr Begin -->
                    <th>Products</th>          
                    <th>NAME</th>
                    <th>DATE</th>
                    <th>QUANTITY</th>
                    <th>PRICE</th>
                    <th>DETAIL</th>                                       
                </tr><!-- tr Finish -->
                            
            </thead><!-- thead Finish -->
             <?php

            global $con;

            $customer_session = $_SESSION['customer_email'];

            $get_customer = "select * from customers where customer_email='$customer_session'";

            $run_customer = mysqli_query($con,$get_customer);

            $row_customer = mysqli_fetch_array($run_customer);

            $customer_id = $row_customer['customer_id'];

            $get_orders = "select * from customer_orders where customer_id='$customer_id' ";

                $run_track = mysqli_query($con, $get_orders);
                while($row_orders = mysqli_fetch_array($run_track)){
                    $size = $row_orders['size'];

                    $order_id = $row_orders['order_id'];
                  
                    $due_amount = $row_orders['due_amount'];

                    $invoice_no = $row_orders['invoice_no'];
                   
                    $order_date = substr($row_orders['order_date'],0,11);
                    
                    $order_status = $row_orders['order_status'];


                    $get_pending_orders = "select * from pending_orders where invoice_no='$invoice_no' ";

                    $run_pending = mysqli_query($con, $get_pending_orders);

                    while($row_pending = mysqli_fetch_array($run_pending)){

                        $product_id = $row_pending['product_id'];

                        $get_product_img = "select * from products where product_id='$product_id' ";
                        $run_product_img = mysqli_query($con, $get_product_img);
                        while($row_product_img = mysqli_fetch_array($run_product_img)){
                            $product_img = $row_product_img['product_img1'];
                            $pro_id= $row_product_img['product_id'];
                            $product_title = $row_product_img['product_title'];
            ?>     
            <?php 
                        echo "<thead><!-- thead Begin -->
                            
                        <tr><!-- tr Begin -->
                            <td><img  src='../admin_area/product_images/$product_img'height='100' width='100'></td>        
                            <td><a href='../details.php?pro_id=$pro_id' src = '' > $product_title </a></td>
                            <td> $order_date</td>
                            <td>$size</td>
                            <td>$ $due_amount</td>
                            <td>
                            <p class='buttons'>

                            <a class='btn btn-default' href='../details.php?pro_id=$pro_id'>

                                View Details

                            </a>
                            </p>
                            </td> 
                                                                               
                        </tr><!-- tr Finish -->
                                    
                    </thead><!-- thead Finish -->  ";
                    
  
            ?>
            <?php }}} ?>
    </table><!--  table table-bordered table-hover Finish  -->     
</div><!--  table-responsive Finish  -->
</div><!-- #content Finish -->