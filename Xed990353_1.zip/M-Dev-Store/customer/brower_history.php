<center><!--  center Begin  -->
    
    <h1> Browser History </h1>
    
    <p class="lead"> You may visit these goods before.</p>
    
    <p class="text-muted">
        
        <a href="../contact.php">Contact Us</a>
        
    </p>
    
</center><!--  center Finish  -->
<div id="content"><!-- #content Begin -->
<div class="table-responsive"><!--  table-responsive Begin  -->
       <table class="table table-bordered table-hover">
            <thead><!-- thead Begin -->
                            
                            <tr><!-- tr Begin -->
                                <th>PRODUCT</th>          
                                <th>NAME</th>
                                <th>PRICE</th>
                                <th>DETAILS</th>  
                                                                    
                            </tr><!-- tr Finish -->
                                        
            </thead><!-- thead Finish -->
                         <?php
            
                        global $con;
            
                        $customer_session = $_SESSION['customer_email'];
            
                        $get_customer = "select * from customers where customer_email='$customer_session'";
            
                        $run_customer = mysqli_query($con,$get_customer);
            
                        $row_customer = mysqli_fetch_array($run_customer);
            
                        $customer_id = $row_customer['customer_id'];
            
                        $get_orders = "select * from brower_history where customer_id='$customer_id' ";
            
  
                        $run_track = mysqli_query($con, $get_orders);
                            while($row_orders = mysqli_fetch_array($run_track)){
                                
            
                                $P_id = $row_orders['p_id'];
                              
                                $pro_img = $row_orders['product_image'];
            
                                $pro_title = $row_orders['product_title'];

                                $pro_price = $row_orders['product_price'];         
                        ?>     
                        <?php 
                                    echo "<thead><!-- thead Begin -->
                                        
                                    <tr><!-- tr Begin -->
                                        <td><img  src='../admin_area/product_images/$pro_img'height='100' width='100'></td>        
                                        <td>$pro_title</a></td>
                                        <td> $pro_price</td>
                                        <td>
                                        <p class='buttons'>
            
                                        <a class='btn btn-default' href='../details.php?pro_id=$P_id'>
            
                                            View Details
            
                                        </a>
                                        </p>
                                        </td> 
                                                                                           
                                    </tr><!-- tr Finish -->
                                                
                                </thead><!-- thead Finish -->  ";
                                
              
                        ?>
                        <?php } ?>
       </table><!--  table table-bordered table-hover Finish  -->    
    </div><!-- container Finish -->
</div><!-- #content Finish -->

