-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2021 at 05:32 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `brower_history`
--

CREATE TABLE `brower_history` (
  `p_id` int(10) NOT NULL,
  `product_title` text NOT NULL,
  `product_image` text NOT NULL,
  `product_price` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brower_history`
--

INSERT INTO `brower_history` (`p_id`, `product_title`, `product_image`, `product_price`, `customer_id`) VALUES
(14, 'Maroon 5 Albums', '微信图片_2021041014194412.jpg', 12, 1),
(15, 'Cat food', 'catfood.jpg', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(255) NOT NULL,
  `qty` int(10) NOT NULL,
  `size` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`p_id`, `ip_add`, `qty`, `size`) VALUES
(14, '::1', 1, 'Normal'),
(15, '::1', 1, 'Golden');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(10) NOT NULL,
  `cat_title` text NOT NULL,
  `cat_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`, `cat_desc`) VALUES
(1, 'Pet foods', 'Best, healthy, all for pets'),
(2, 'E-devices', 'Select E-device here.'),
(3, 'Games', 'Select your favorite games.'),
(4, 'Musics', 'Select your favorite music.');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(10) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_pass` varchar(255) NOT NULL,
  `customer_country` text NOT NULL,
  `customer_city` text NOT NULL,
  `customer_contact` varchar(255) NOT NULL,
  `customer_address` text NOT NULL,
  `customer_image` text NOT NULL,
  `customer_ip` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_name`, `customer_email`, `customer_pass`, `customer_country`, `customer_city`, `customer_contact`, `customer_address`, `customer_image`, `customer_ip`) VALUES
(1, 'TEST', 'test@163.com', '123456', 'CN', 'Suzhou', '0111-111-111', 'Suzhou Street', '微信图片_202104101419447.jpg', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `customer_orders`
--

CREATE TABLE `customer_orders` (
  `order_id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `due_amount` int(100) NOT NULL,
  `invoice_no` int(100) NOT NULL,
  `qty` int(10) NOT NULL,
  `size` text NOT NULL,
  `order_date` date NOT NULL,
  `order_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_orders`
--

INSERT INTO `customer_orders` (`order_id`, `customer_id`, `due_amount`, `invoice_no`, `qty`, `size`, `order_date`, `order_status`) VALUES
(1, 1, 12, 385464961, 1, 'Normal', '2021-04-14', 'Complete'),
(2, 1, 12, 511926947, 1, 'Normal', '2021-04-14', 'Complete'),
(3, 1, 10, 1932803052, 1, '', '2021-04-15', 'Complete'),
(4, 1, 400, 52095713, 1, '', '2021-04-17', 'pending'),
(5, 1, 12, 52095713, 1, 'Golden', '2021-04-17', 'pending'),
(6, 1, 10, 52095713, 1, '', '2021-04-17', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(10) NOT NULL,
  `invoice_no` int(10) NOT NULL,
  `amount` int(10) NOT NULL,
  `payment_mode` text NOT NULL,
  `ref_no` int(10) NOT NULL,
  `code` int(10) NOT NULL,
  `payment_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `invoice_no`, `amount`, `payment_mode`, `ref_no`, `code`, `payment_date`) VALUES
(1, 0, 0, 'Paypall', 534533, 1223123, '20121221'),
(2, 2147483647, 1231531, 'Back Code', 23123, 123123, '20110102'),
(3, 123123, 1231231, 'Back Code', 123123, 123123, '23123'),
(4, 364645645, 2147483647, 'Paypall', 456456456, 456456456, '20160302'),
(5, 5, 45, 'Western Union', 45, 45, '20100102'),
(6, 453453, 453453, 'Back Code', 453453, 453453, '453453');

-- --------------------------------------------------------

--
-- Table structure for table `pending_orders`
--

CREATE TABLE `pending_orders` (
  `order_id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `invoice_no` int(10) NOT NULL,
  `product_id` text NOT NULL,
  `qty` int(10) NOT NULL,
  `size` text NOT NULL,
  `order_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pending_orders`
--

INSERT INTO `pending_orders` (`order_id`, `customer_id`, `invoice_no`, `product_id`, `qty`, `size`, `order_status`) VALUES
(1, 1, 385464961, '17', 1, 'Normal', 'Complete'),
(2, 1, 511926947, '14', 1, 'Normal', 'Complete'),
(3, 1, 1932803052, '15', 1, '', 'Complete'),
(4, 1, 52095713, '8', 1, '', 'pending'),
(5, 1, 52095713, '14', 1, 'Golden', 'pending'),
(6, 1, 52095713, '15', 1, '', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(10) NOT NULL,
  `p_cat_id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `product_title` text NOT NULL,
  `product_img1` text NOT NULL,
  `product_img2` text NOT NULL,
  `product_img3` text NOT NULL,
  `product_price` int(10) NOT NULL,
  `product_keywords` text NOT NULL,
  `product_desc` text NOT NULL,
  `product_label` text NOT NULL,
  `product_sale` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `p_cat_id`, `cat_id`, `date`, `product_title`, `product_img1`, `product_img2`, `product_img3`, `product_price`, `product_keywords`, `product_desc`, `product_label`, `product_sale`) VALUES
(1, 6, 4, '2021-04-12 07:07:48', 'Ed Sheeran Albums', '微信图片_20210410141944.jpg', '微信图片_202104101419441.jpg', '微信图片_202104101419442.jpg', 12, 'Ed Sheeran Latest Albums', 'Enjoy the VOICE!!!', 'sale', 11),
(2, 6, 4, '2021-04-11 12:58:10', 'Justin Bieber Albums', '微信图片_202104101419444.jpg', '微信图片_202104101419445.jpg', '微信图片_202104101450301.jpg', 15, 'Justin Bieber Latest Albums', 'Enjoy the VOICE!!!', 'new', 0),
(3, 6, 4, '2021-04-12 07:34:09', 'Taylor Swift Albums', '微信图片_2021041014194410.jpg', '微信图片_202104101419447.jpg', '微信图片_202104101419449.jpg', 20, 'Taylor Swift Latest Albums', 'Enjoy the VOICE!!!', 'new', 0),
(5, 6, 4, '2021-04-11 12:57:59', 'Kygo Albums', '微信图片_202104101419448.jpg', '微信图片_202104101450302.jpg', '微信图片_202104101419446.jpg', 10, 'Kygo Latest Albums', 'Enjoy the VOICE!!!', 'new', 0),
(6, 4, 2, '2021-04-11 13:30:44', 'SONY Camera', 'sony.jpg', 'camera.jpg', 'camera2.jpg', 600, 'SONY Latest Camera', 'SONY Camera, best Camera', 'sale', 570),
(7, 5, 3, '2021-04-12 07:34:21', 'Nintendo Pokemon', 'Nintendo.jpg', 'pokemon.jpg', 'pokemon02.jpg', 35, 'Pokemon Latest game', 'We all love Pokemon  game', 'sale', 30),
(8, 2, 2, '2021-04-12 07:34:27', 'Nintendo Switch', 'Nintendo.jpg', 'switch.jpg', 'switch2.jpg', 400, 'Switch', 'Nintendo Game,best Game', 'sale', 399),
(9, 2, 2, '2021-04-11 12:58:02', 'SONY Play Station 5', 'sony.jpg', 'ps502.jpg', 'ps5.jpg', 500, 'Play Station 5', 'SONY Play Station 5,best game machine ', 'new', 0),
(14, 6, 4, '2021-04-11 13:36:53', 'Maroon 5 Albums', '微信图片_2021041014194412.jpg', '微信图片_2021041014194413.jpg', '微信图片_2021041014194411.jpg', 12, 'Maroon 5 Latest Albums', 'Enjoy the VOICE!!!', 'sale', 11),
(15, 1, 1, '2021-04-12 07:34:38', 'Cat food', 'catfood.jpg', 'foodcat.jpg', 'foodcat02.jpg', 10, 'Cat food', 'Best cat food', 'new', 0),
(17, 3, 1, '2021-04-12 07:34:41', 'Dog food', 'dogfood.jpg', 'dogfood02.jpg', 'dogfood03.jpg', 12, 'Best dog food', 'Best dog food', 'new', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `p_cat_id` int(10) NOT NULL,
  `p_cat_title` text NOT NULL,
  `p_cat_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`p_cat_id`, `p_cat_title`, `p_cat_desc`) VALUES
(1, 'Cat foods', 'Select your cats\' foods.'),
(2, 'Game Machines', 'All world popular game machines are here.'),
(3, 'Dog foods', 'Best dog foods are all here.'),
(4, 'Cameras', 'All your favorite camera are here.'),
(5, 'Games', 'All your favorite games are here.'),
(6, 'Albums', 'Here is a collection of popular albums by many of today\'s artists.');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `slide_id` int(10) NOT NULL,
  `slide_name` varchar(255) NOT NULL,
  `slide_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`slide_id`, `slide_name`, `slide_image`) VALUES
(1, 'Slide number 1', 'slide-1.jpg'),
(2, 'Slide number 2', 'slide-2.jpg'),
(3, 'Slide number 3', 'slide-3.jpg'),
(4, 'Slide number 4', 'slide-4.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brower_history`
--
ALTER TABLE `brower_history`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `customer_orders`
--
ALTER TABLE `customer_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `pending_orders`
--
ALTER TABLE `pending_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`p_cat_id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`slide_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brower_history`
--
ALTER TABLE `brower_history`
  MODIFY `p_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer_orders`
--
ALTER TABLE `customer_orders`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pending_orders`
--
ALTER TABLE `pending_orders`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `p_cat_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `slide_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
